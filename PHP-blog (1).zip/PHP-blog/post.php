<?php
require "connection.php";

$post_id=$_GET["id"];

$parentCommentsQuery="SELECT * FROM comments WHERE post_id=:post_id AND parent_id IS NULL ORDER BY created_at  DESC";
$stmt1=$pdo->prepare($parentCommentsQuery);
$stmt1->bindParam(":post_id",$post_id);
$stmt1->execute();
$parentComments=$stmt1->fetchAll(PDO::FETCH_ASSOC);





?>



<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="This is demo page made for YouBee.ai's programming courses">
  <meta name="author" content="YouBee.ai">

  <title>Post - YouBee Blog Template</title>

  <!-- Bootstrap Core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="css/simple-blog-template.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <?php require "components/navbar.php" ; ?>



  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <!-- Blog Post Content Column -->
      <div class="col-lg-12">

        <!-- Blog Post -->

        <!-- Title -->
        <h1 class="post-title">Blog Post Title</h1>

        <!-- Author -->
        <a href="author.html" class="lead">
          by Author
        </a>

        <hr>

        <!-- Date/Time -->
        <p><span class="glyphicon glyphicon-time"></span> Posted on August 24, 2024 at 9:00 PM</p>

        <hr>

        <p>post will show here</p>
        <hr>

        <!-- Blog Comments -->

        <!-- Comments Form -->
        <div class="well">
          <h4>Leave a Comment:</h4>
          <form action="actions/comment.php" method="POST">
            <input type="hidden" name="post_id" value ="<?= $post_id ?>">
            <input type="hidden" name="parent_id" value="">
            <div class="form-group">
              <input type="text" name="name" placeholder="enter your name">

            </div>
            <div class="form-group">
              <textarea name="comment" class="form-control" id="" placeholder="your comment" required>

              </textarea>
              
            </div>
            <button type="submit" class="btn btn-primary">submit</button>
            
          </form>
        </div>

        <hr>

        <!-- Posted Comments -->

        <!-- Comment -->
         <?php foreach($parentComments as $comment): ?>
        <div class="media">
          <a class="pull-left" href="#">
            <img class="media-object" src="imgs/default.png" width="64px" height="64px" alt="">
          </a>
          <div class="media-body">
            <h4 class="media-heading"><?= $comment["name"] ?>
              <small><?= $comment["created_at"] ?></small>
            </h4>
            <?= $comment["comment"] ?>
            <form action="actions/comment.php" method="POST">
            <input type="hidden" name="post_id" value ="<?= $post_id ?>">
            <input type="hidden" name="parent_id" value="">
            <div class="form-group">
              <input type="text" name="name" placeholder="enter your name">

            </div>
            <div class="form-group">
              <textarea name="comment" class="form-control" id="" placeholder="your comment" required>

              </textarea>
              
            </div>
            <button type="submit" class="btn btn-primary">submit</button>
            
          </form>
            <!-- Nested Comment -->
            <?php endforeach; ?>
        
        </div>

      </div>
    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
 

  <?php require "components/footer.php" ; ?>

  <!-- jQuery -->
  <script src="js/jquery.js"></script>

  <!-- Bootstrap Core JavaScript -->
  <script src="js/bootstrap.min.js"></script>

</body>

</html>