<?php

$host="localhost";
$dbname="learn";
$user="root";
$pass="";

try{
    $pdo= new PDO("mysql:host=$host;dbname=$dbname",$user,$pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    
}
catch(PDOExeption $error){
    echo "connection failed".$error->getMessage();

}


