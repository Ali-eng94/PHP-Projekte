<?php
session_start();
?>
<?php


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/styles.css">
    <title>Register</title>
</head>
<body>
    <div class="container">
        <h1>Register</h1>
        <?php
        if(isset($_SESSION["error"])){
            echo $_SESSION["error"];
            unset($_SESSION["error"]);

        }


?>
       
        <form action="actions/register_action.php" method="POST">
            <input type="text" name="name" placeholder="Name" required>
            <br>
            <input type="email" name="email" placeholder="Email" required>
            <br>
            <input type="password" name="password" placeholder="Password" required>
            <br>
            <input type="submit" value="Register">
        </form>
        <p>Already have an account? <a href="login.php">Login here</a>.</p>
    </div>
</body>
</html>
