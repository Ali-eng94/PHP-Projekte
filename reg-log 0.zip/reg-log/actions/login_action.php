<?php
session_start();
require "../connection.php";
if($_SERVER["REQUEST_METHOD"]=="POST"){
    try{
    
        $email=htmlspecialchars(trim($_POST["email"]));  
        $password=htmlspecialchars(trim($_POST["password"])); 

        if( empty($email) || empty($password)){
            $_SESSION["error"]="all fields are required";
            header("Location:../login.php");
            exit();
        }
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            $_SESSION["error"]="invalid email format";
            header("Location:../login.php");
            exit();
        } 
        //password->hash(pass)-> dg644367rt34r4g


        $sql="SELECT * FROM users WHERE email =:e";
        $stmt=$pdo->prepare($sql);
        $stmt->bindParam(':e',$email);
        $stmt->execute();
        

// elie123  -> 3tr634tr6f45h5hf84 
//elie1234  ->    

        $user=$stmt->fetch(PDO::FETCH_ASSOC);
        // print_r($user);
        if( $user &&   password_verify($password,$user["password"])){   //$2y$10$tS1qj3ACV0ysoYM3.XMmwOxpewwkYp/WyCGpUQCX04ORYtaK/Brg.
            $_SESSION["user_id"]=$user["id"];
            $_SESSION["user_name"]=$user["name"];
            $_SESSION["logged_in"]=true;
            header("Location:../home.php");     
        }
        else{
            $_SESSION["error"]="invalid email or password";
            header("Location:../login.php");
            exit();
        }

    }
    catch(PDOException $e){
        $_SESSION["error"]="an error occured".$e->getMessage();
        header("Location:../login.php");

      

       
    }
}