<?php

require "../connection.php";
session_start();

if($_SERVER["REQUEST_METHOD"]=="POST"){
    try{
        $name=htmlspecialchars(trim($_POST["name"]));    
        $email=htmlspecialchars(trim($_POST["email"]));  
        $password=htmlspecialchars(trim($_POST["password"]));  
        
        if(empty($name) || empty($email) || empty($password)){
            $_SESSION["error"]="all fields are required";
            header("Location:../register.php");
            exit();
        }
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            $_SESSION["error"]="invalid email format";
            header("Location:../register.php");
            exit();
        }
        $hashed_pass=password_hash($password,PASSWORD_DEFAULT);


        $sql="INSERT INTO users (name,email,password) VALUES (:n,:e,:p)";
        $stmt=$pdo->prepare($sql);
        $stmt->bindParam(':n',$name);
        $stmt->bindParam(':e',$email);
        $stmt->bindParam(':p',$hashed_pass);
        $stmt->execute();
        $_SESSION["success"]="Registered successfully";
        header("Location:../login.php");


    }
    catch(PDOException $e){
        if($e->getCode()==23000){
            $_SESSION["error"]="email already in use";

        }
        else{
            $_SESSION["error"]="an error occured ".$e->getMessage();
        }
        header("Location:../register.php");

    }
}