<?php
require "../connection.php";
session_start();

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $email=htmlspecialchars(trim($_POST["email"]));
    $password=htmlspecialchars(trim($_POST["password"]));

if( empty($email) || empty($password)){
    $_SESSION["error"]="all fileds are required";
    header("Location:../login.php");
    exit();
}
try{
    $sql="SELECT id,name,password,role FROM users WHERE email=:e";
    $stmt=$pdo->prepare($sql);
    $stmt->bindParam(":e",$email,PDO::PARAM_STR);
    $stmt->execute();
    $user=$stmt->fetch(PDO::FETCH_ASSOC);



    if($user && password_verify($password,$user["password"])){
        $_SESSION["user_id"]=$user["id"];
        $_SESSION["user_name"]=$user["name"];
        $_SESSION["role"]=$user["role"];
        $_SESSION["loggedIn"]=true;

        if($_SESSION["role"]=="super_admin"){
            header("Location:../adminDashbored.php");
        }
        elseif($_SESSION["role"]=="instructor"){
            header("Location:../instructorDashbored.php");

        }
        else{
            header("Location:../home.php");

        }
    }
    else{
        $_SESSION["error"]="invalid email or password";
        header("Location:../login.php");
        exit();
    }




}
catch(PDOException $e){
    $_SESSION["error"]="database error : ".$e->getMessage();
    header("Location:../login.php");
    exit();
}



}