<?php
require "../connection.php";
session_start();

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $name=htmlspecialchars(trim($_POST["name"]));
    $email=htmlspecialchars(trim($_POST["email"]));
    $password=htmlspecialchars(trim($_POST["password"]));


if(strlen($password) <8){
$_SESSION["error"]="passworsd at least 8 characters";
header("Location:../register.php");
exit();

}
if(!filter_var($email,FILTER_SANITIZE_EMAIL)){
    $_SESSION["error"]="PLEASE ETNER A REAL EMAIL ";
    header("Location:../register.php");
    exit();

}

if(empty($name) || empty($email) || empty($password)){
    $_SESSION["error"]="all fileds are required";
    header("Location:../register.php");
    exit();
}
try{
    $hashed_pass=password_hash($password,PASSWORD_BCRYPT);
    $sql="INSERT INTO users (name, email,password) VALUES (:n,:e,:p)";
    $stmt=$pdo->prepare($sql);
    $stmt->bindParam(":n",$name,PDO::PARAM_STR);
    $stmt->bindParam(":e",$email,PDO::PARAM_STR);
    $stmt->bindParam(":p",$hashed_pass,PDO::PARAM_STR);
    if($stmt->execute()){
        $_SESSION["success"]="registered successfully";
        header("Location:../login.php");
        exit();
    }
}
catch(PDOException $e){
    if($e->getCode()==23000){
        $_SESSION["error"]="email already in use";
        header("Location:../register.php");
        exit();

    }
    else{
        $_SESSION["error"]="error from database";
        header("Location:../register.php");
        exit();

    }

} 
}