<?php

header("Content-Type:application/json");
require "connection.php";


$data=json_decode(file_get_contents("php://input"),true);

// body{
// name:
// age,
// id
// }

if(!isset($data["name"]) || empty($data["name"])){
    echo json_encode(["message"=>"name is required"]);
    exit();
}

$name=$data["name"];

$sql="INSERT INTO users (name) VALUES (:n)";
$stmt=$pdo->prepare($sql);
$stmt->bindParam(":n",$name);
$stmt->execute();

echo json_encode(["message"=>"user added succefully","id"=>1])



?>