
<?php
// session_start();
// require "components/not_logged_in.php";

?>



<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="This is demo page made for YouBee.ai's programming courses">
  <meta name="author" content="YouBee.ai">

  <title>Home - YouBee Blog Template</title>

  <!-- Bootstrap Core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="css/simple-blog-template.css" rel="stylesheet">


</head>

<body>

<?php require "components/navbar.php" ; ?>


  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <!-- Blog Entries Column -->
      <div class="col-md-12">

        <!-- First Blog Post -->
        <h2 class="post-title">
          <a href="post.html">Blog Post Title</a>
        </h2>
        <a href="author.html" class="lead">
          by Author
        </a>
        <p><span class="glyphicon glyphicon-time"></span> Posted on August 28, 2024 at 10:00 PM</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore, veritatis, tempora, necessitatibus
          inventore nisi quam quia repellat ut tempore laborum possimus eum dicta id animi corrupti debitis ipsum
          officiis rerum.</p>
        <a class="btn btn-default" href="post.html">Read More</a>
        <a class="btn btn-default" href="post.html">Like</a>

        <hr>

        <!-- Second Blog Post -->
        <h2 class="post-title">
          <a href="post.html">Blog Post Title</a>
        </h2>
        <a href="author.html" class="lead">
          by Author
        </a>
        <p><span class="glyphicon glyphicon-time"></span> Posted on August 28, 2024 at 10:45 PM</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quibusdam, quasi, fugiat, asperiores harum
          voluptatum tenetur a possimus nesciunt quod accusamus saepe tempora ipsam distinctio minima dolorum
          perferendis labore impedit voluptates!</p>
        <a class="btn btn-default" href="post.html">Read More</a>
        <a class="btn btn-default" href="post.html">Like</a>

        <hr>

        <!-- Third Blog Post -->
        <h2 class="post-title">
          <a href="post.html">Blog Post Title</a>
        </h2>
        <a href="author.html" class="lead">
          by Author
        </a>
        <p><span class="glyphicon glyphicon-time"></span> Posted on August 28, 2024 at 10:45 PM</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, voluptates, voluptas dolore ipsam
          cumque quam veniam accusantium laudantium adipisci architecto itaque dicta aperiam maiores provident id
          incidunt autem. Magni, ratione.</p>
        <a class="btn btn-default" href="post.html">Read More</a>
        <a class="btn btn-default" href="post.html">Like</a>

        <hr>

      

      </div>

    </div>
    <!-- /.row -->

  </div>
  <?php require "components/footer.php" ; ?>

 
  <!-- jQuery -->
  <script src="js/jquery.js"></script>

  <!-- Bootstrap Core JavaScript -->
  <script src="js/bootstrap.min.js"></script>

</body>

</html>