<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="This is demo page made for YouBee.ai's programming courses">
  <meta name="author" content="YouBee.ai">

  <title>Post - YouBee Blog Template</title>

  <!-- Bootstrap Core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="css/simple-blog-template.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <?php require "components/navbar.php" ; ?>



  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <!-- Blog Post Content Column -->
      <div class="col-lg-12">

        <!-- Blog Post -->

        <!-- Title -->
        <h1 class="post-title">Blog Post Title</h1>

        <!-- Author -->
        <a href="author.html" class="lead">
          by Author
        </a>

        <hr>

        <!-- Date/Time -->
        <p><span class="glyphicon glyphicon-time"></span> Posted on August 24, 2024 at 9:00 PM</p>

        <hr>

        <!-- Post Content -->
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus, vero, obcaecati, aut, error quam sapiente
          nemo saepe quibusdam sit excepturi nam quia corporis eligendi eos magni recusandae laborum minus inventore?
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut, tenetur natus doloremque laborum quos iste
          ipsum rerum obcaecati impedit odit illo dolorum ab tempora nihil dicta earum fugiat. Temporibus, voluptatibus.
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos, doloribus, dolorem iusto blanditiis unde eius
          illum consequuntur neque dicta incidunt ullam ea hic porro optio ratione repellat perspiciatis. Enim, iure!
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error, nostrum, aliquid, animi, ut quas placeat
          totam sunt tempora commodi nihil ullam alias modi dicta saepe minima ab quo voluptatem obcaecati?</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum, dolor quis. Sunt, ut, explicabo, aliquam
          tenetur ratione tempore quidem voluptates cupiditate voluptas illo saepe quaerat numquam recusandae? Qui,
          necessitatibus, est!</p>

        <hr>

        <!-- Blog Comments -->

        <!-- Comments Form -->
        <div class="well">
          <h4>Leave a Comment:</h4>
          <form role="form">
            <div class="form-group">
              <textarea class="form-control" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>

        <hr>

        <!-- Posted Comments -->

        <!-- Comment -->
        <div class="media">
          <a class="pull-left" href="#">
            <img class="media-object" src="imgs/default.png" width="64px" height="64px" alt="">
          </a>
          <div class="media-body">
            <h4 class="media-heading">Elie Amin
              <small>August 25, 2024 at 9:30 PM</small>
            </h4>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere ratione doloribus amet numquam eaque sit
            fugiat, repudiandae cupiditate quia dolores asperiores a quaerat nobis culpa corrupti natus saepe, obcaecati
            atque.
          </div>
        </div>

        <!-- Comment -->
        <div class="media">
          <a class="pull-left" href="#">
            <img class="media-object" src="imgs/default.png" width="64px" height="64px" alt="">
          </a>
          <div class="media-body">
            <h4 class="media-heading">Hasan Nahleh
              <small>August 25, 2024 at 9:30 PM</small>
            </h4>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Commodi veniam iure, ex repellat porro quia, quas
            reprehenderit error soluta dolores aut esse ad non officia nam. Ipsam error repudiandae incidunt!
            <!-- Nested Comment -->
            <div class="media">
              <a class="pull-left" href="#">
                <img class="media-object" src="imgs/default.png" width="64px" height="64px" alt="">
              </a>
              <div class="media-body">
                <h4 class="media-heading">Ali Nahleh
                  <small>August 25, 2024 at 9:30 PM</small>
                </h4>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sint tempore veritatis numquam libero qui
                repudiandae laudantium architecto cum reiciendis ipsam placeat, omnis sapiente voluptas repellat nihil
                nesciunt sequi ex consequuntur?
              </div>
            </div>
            <!-- End Nested Comment -->
          </div>
        </div>

      </div>
    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
 

  <?php require "components/footer.php" ; ?>

  <!-- jQuery -->
  <script src="js/jquery.js"></script>

  <!-- Bootstrap Core JavaScript -->
  <script src="js/bootstrap.min.js"></script>

</body>

</html>